import React from "react";

function Homepage() {
    return (
        <div className="bg-gray-50 min-h-screen flex flex-col">
    
          {/* Header Section */}
          <header className="bg-teal-400 text-white p-6">
            <div className="max-w-7xl mx-auto flex justify-between items-center">
              <h1 className="text-4xl font-extrabold">My Awesome Website</h1>
              <nav>
                <ul className="flex space-x-8">
                  <li><a href="#home" className="hover:text-teal-700">Home</a></li>
                  <li><a href="#about" className="hover:text-teal-700">About</a></li>
                  <li><a href="#services" className="hover:text-teal-700">Services</a></li>
                  <li><a href="#contact" className="hover:text-teal-700">Contact</a></li>
                </ul>
              </nav>
            </div>
          </header>
    
          {/* Main Content Section */}
          <main className="flex-grow py-12">
            <section className="max-w-6xl mx-auto text-center px-4">
              <h2 className="text-5xl font-bold text-teal-600 mb-4">Welcome to Our Website!</h2>
              <p className="text-lg text-gray-700 mb-12 max-w-3xl mx-auto">
                We are thrilled to have you here. Explore our services and learn more about how we can help you.
              </p>
    
              <div className="flex flex-wrap justify-center gap-12">
                <div className="bg-white shadow-xl rounded-lg p-8 w-full sm:w-72 max-w-xs">
                  <h3 className="text-2xl font-semibold text-teal-600 mb-4">Our Services</h3>
                  <p className="text-gray-600 mb-4">
                    We provide a variety of services tailored to your needs. Whether it's web development or design, we have you covered.
                  </p>
                  <a href="#services" className="text-teal-500 hover:text-teal-700">Learn More</a>
                </div>
                <div className="bg-white shadow-xl rounded-lg p-8 w-full sm:w-72 max-w-xs">
                  <h3 className="text-2xl font-semibold text-teal-600 mb-4">Get in Touch</h3>
                  <p className="text-gray-600 mb-4">
                    Have any questions or want to start a project? Reach out to us, and we'll get back to you promptly!
                  </p>
                  <a href="#contact" className="text-teal-500 hover:text-teal-700">Contact Us</a>
                </div>
              </div>
            </section>
          </main>
    
          {/* Footer Section */}
          <footer className="bg-teal-400 text-white p-6">
            <div className="max-w-7xl mx-auto text-center">
              <p>&copy; 2024 My Awesome Website. All Rights Reserved.</p>
            </div>
          </footer>
    
        </div>
      );
}

export default Homepage;